
function createModal(title, content, onSubmit = null, className = '') {
  document.getElementById('customModal')?.remove();

  document.body.insertAdjacentHTML('beforeend', `
    <dialog id="customModal" class="custom-modal ${className}">
      <div class="modal-header">
        <h2></h2>
        <button type="button" class="closeModalbtn">&times;</button>
      </div>

      <form id="modalForm">
        <div class="modal-body">
          ${content}
        </div>

        <div class="modal-actions">
          <button type="button" class="cancelModalbtn">Cancel</button>
          <button type="submit" class="saveModalbtn">Save</button>
        </div>
      </form>
    </dialog>
  `);

  const modal = document.getElementById('customModal');
  const form = document.getElementById('modalForm');
  const saveBtn = form.querySelector('.saveModalbtn');
  const cancelBtn = form.querySelector('.cancelModalbtn');

  modal.querySelector('.modal-header h2').textContent = title;

  modal.querySelector('.closeModalbtn').onclick = () => modal.close();
  cancelBtn.onclick = () => modal.close();

  modal.addEventListener('close', () => modal.remove());

  if (!onSubmit) {
    saveBtn.remove();
    cancelBtn.textContent = 'Close';
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();

    if (!onSubmit) return;

    saveBtn.disabled = true;

    try {
      const result = await onSubmit(new FormData(form), form);

      if (result === false) return;

      modal.close();
    } catch (error) {
      console.error(error);
      const box = form.querySelector('.modal-error');
      if (box) box.textContent = 'Unable to save: ' + (error.message || error);
      else alert('Unable to save. Please try again.');
    } finally {
      saveBtn.disabled = false;
    }
  });

  modal.showModal();

  return modal;
}
