const sidebarButtons = document.querySelectorAll('.sidebar-btn[data-target]');
const pageTitle = document.getElementById('pageTitle');

const adminPages = [
  'dashboard',
  'account-management',
  'transaction-history',
  'inventory'
];

function showAdminPage(target) {
  adminPages.forEach(id => {
    const section = document.getElementById(id);

    if (section) {
      section.hidden = id !== target;
    } else {
      console.warn(`Missing section: ${id}`);
    }
  });

  sidebarButtons.forEach(button => {
    button.classList.toggle(
      'active',
      button.dataset.target === target
    );
  });

  const titles = {
    dashboard: 'Dashboard',
    'account-management': 'Manage Account',
    'transaction-history': 'Transaction History',
    inventory: 'Inventory'
  };

  pageTitle.textContent = titles[target] ?? 'Dashboard';

  if (target === 'transaction-history') loadTransactions();
  if (target === 'account-management') loadAccounts();
  if (target === 'inventory') loadInventory();
}

sidebarButtons.forEach(button => {
  button.addEventListener('click', () => {
    showAdminPage(button.dataset.target);
  });
});

showAdminPage('dashboard');

document.getElementById('logoutBtn').addEventListener('click', () => {
  const modal = createModal('Logout?', '<p>Are you sure you want to logout?</p>', () => {
    location.href = '../auth/logout.php';
    return false;
  });

  modal.querySelector('.saveModalbtn').textContent = 'Logout';
});
