document.getElementById('refreshProducts').onclick = async event => {
    const button = event.currentTarget;

    if (button.disabled) return;

    button.disabled = true;
    button.classList.add('loading');

    try {
      await reloadProducts();
    } catch (error) {
      console.error(error);
      showModal('Unable to refresh products. Please try again.');
    } finally {
      button.disabled = false;
      button.classList.remove('loading');
    }
  };

  function confirmLogout() {
    showModal('Logout?', () => {
      location.href = '../auth/logout.php';
    });
  }