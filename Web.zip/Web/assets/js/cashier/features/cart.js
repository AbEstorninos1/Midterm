const cartItems = document.getElementById('cartItems');

function addCart(product, quantity) {
  const total = product.price * quantity;

  cartItems.insertAdjacentHTML('beforeend', `
    <div class="cart-item"
      data-product-id="${product.productId}"
      data-variant-id="${product.variantId ?? ''}">

      <div class="cart-item-quantity">${quantity}</div>

      <div class="cart-item-details">
        <p>${escapeHTML(product.product)}</p>
        <span>${escapeHTML(product.variant ?? '')}</span>
        <span class="line-total">₱${total.toFixed(2)}</span>
      </div>

      <button class="cart-remove" type="button">×</button>
    </div>
  `);
}

cartItems.addEventListener('click', event => {
  if (event.target.classList.contains('cart-remove')) {
    event.target.closest('.cart-item').remove();
  }
});

function updateCartTotal() {
  let total = 0;

  cartItems.querySelectorAll('.line-total').forEach(line => {
    total += Number(line.textContent.replace(/[^0-9.]/g, ''));
  });

  document.getElementById('cartTotalAmount').textContent = '₱' + total.toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}


new MutationObserver(updateCartTotal).observe(cartItems, { childList: true });
updateCartTotal();
