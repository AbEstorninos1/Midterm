<?php
//start and destoy mo yung session and header location ka sa index.php(login pages)

?>

