<?php


session_start();
session_destroy();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
  <div class="login-container">
    <div class="login-box">
      <header>
        <h1>Login</h1>
      </header>

      <form id="loginForm">
        <input type="text" id="username" placeholder="Username" required>
        <input type="password" id="password" placeholder="Password" required>
        <p id="message" class="form-message"></p>
        <input type="submit" value="Login">
      </form>

      <div class="create-account">
        Create an Account?<a href="./register.php">Create Account</a>
      </div>
    </div>
  </div>

  <div class="loading-screen" id="loadingScreen" hidden>
    <div class="loading-box">
      <div class="loading-spinner"></div>
      <p id="loadingText">Loading...</p>
      <div class="loading-track">
        <div class="loading-bar" id="loadingBar"></div>
      </div>
    </div>
  </div>

  <script>window.APP_ROOT = './';</script>
  <script src="./assets/js/shared/imageCache.js"></script>
  <script src="./assets/js/login.js"></script>
</body>
</html>
