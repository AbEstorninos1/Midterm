<?php
header('Content-Type: application/json');
ini_set('display_errors', '0');

set_exception_handler(function ($e) {
  http_response_code(500);
  echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
});
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host = '127.0.0.1';
$user = 'root';
$password = 'root';
$database = 'POS';

try {
  $conn = new mysqli($host, $user, $password, $database);
  $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
  
  die(json_encode(['success' => false, 'message' => 'Database connection failed']));
}
